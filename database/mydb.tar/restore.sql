--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg120+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mobelease;
--
-- Name: mobelease; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE mobelease WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mobelease OWNER TO admin;

\connect mobelease

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.employee (
    employeeid integer NOT NULL,
    employeephoto bytea,
    firstname character varying(50),
    lastname character varying(50),
    phoneno character varying(15),
    password character varying(300),
    email character varying(100)
);


ALTER TABLE public.employee OWNER TO admin;

--
-- Name: Employee_EmployeeID_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Employee_EmployeeID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Employee_EmployeeID_seq" OWNER TO admin;

--
-- Name: Employee_EmployeeID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Employee_EmployeeID_seq" OWNED BY public.employee.employeeid;


--
-- Name: admin; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.admin (
    serial integer NOT NULL,
    email character varying(100),
    password character varying(300)
);


ALTER TABLE public.admin OWNER TO admin;

--
-- Name: admin_Serial_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."admin_Serial_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."admin_Serial_seq" OWNER TO admin;

--
-- Name: admin_Serial_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."admin_Serial_seq" OWNED BY public.admin.serial;


--
-- Name: assigndevice; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.assigndevice (
    assignid integer NOT NULL,
    employeeid integer,
    deviceid integer,
    quantity smallint,
    "timestamp" timestamp with time zone
);


ALTER TABLE public.assigndevice OWNER TO admin;

--
-- Name: assigndevice_assignid_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.assigndevice_assignid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assigndevice_assignid_seq OWNER TO admin;

--
-- Name: assigndevice_assignid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.assigndevice_assignid_seq OWNED BY public.assigndevice.assignid;


--
-- Name: creditinstallment; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.creditinstallment (
    installmentid integer NOT NULL,
    saleid integer,
    deadline timestamp with time zone,
    paymentdate timestamp with time zone,
    status character varying(20),
    promisedamount integer,
    amountpaid integer
);


ALTER TABLE public.creditinstallment OWNER TO admin;

--
-- Name: creditinstallment_installmentid_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.creditinstallment_installmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.creditinstallment_installmentid_seq OWNER TO admin;

--
-- Name: creditinstallment_installmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.creditinstallment_installmentid_seq OWNED BY public.creditinstallment.installmentid;


--
-- Name: devicesale; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.devicesale (
    saleid integer NOT NULL,
    saletype character varying(6),
    employeeid integer,
    customername character varying(50),
    customeridimage bytea,
    phoneno character varying(15),
    language character varying(50),
    unit character varying(30),
    farm character varying(100),
    itemarray json,
    totalcost character varying(20),
    totalsale character varying(20),
    remark character varying(1000),
    "timestamp" timestamp with time zone,
    status character varying(10),
    amountleft character varying(20),
    paymentalert integer DEFAULT 1
);


ALTER TABLE public.devicesale OWNER TO admin;

--
-- Name: devicesale_saleid_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.devicesale_saleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devicesale_saleid_seq OWNER TO admin;

--
-- Name: devicesale_saleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.devicesale_saleid_seq OWNED BY public.devicesale.saleid;


--
-- Name: farm; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.farm (
    farmid integer NOT NULL,
    farmname character varying(100) NOT NULL
);


ALTER TABLE public.farm OWNER TO admin;

--
-- Name: farm_farmid_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.farm_farmid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farm_farmid_seq OWNER TO admin;

--
-- Name: farm_farmid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.farm_farmid_seq OWNED BY public.farm.farmid;


--
-- Name: farmunit; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.farmunit (
    unitname character varying(100) NOT NULL,
    farmname character varying(100)
);


ALTER TABLE public.farmunit OWNER TO admin;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.inventory (
    deviceid integer NOT NULL,
    company character varying(50),
    devicedetail character varying(100),
    cost character varying(9),
    storage character varying(50),
    itemtype character varying(50),
    remark character varying(1000),
    inuse character varying(1) DEFAULT 1 NOT NULL
);


ALTER TABLE public.inventory OWNER TO admin;

--
-- Name: inventory_deviceid_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.inventory_deviceid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_deviceid_seq OWNER TO admin;

--
-- Name: inventory_deviceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.inventory_deviceid_seq OWNED BY public.inventory.deviceid;


--
-- Name: itemtable; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.itemtable (
    serialno integer NOT NULL,
    itemtype character varying(50)
);


ALTER TABLE public.itemtable OWNER TO admin;

--
-- Name: itemtable_serialno_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.itemtable_serialno_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.itemtable_serialno_seq OWNER TO admin;

--
-- Name: itemtable_serialno_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.itemtable_serialno_seq OWNED BY public.itemtable.serialno;


--
-- Name: admin serial; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.admin ALTER COLUMN serial SET DEFAULT nextval('public."admin_Serial_seq"'::regclass);


--
-- Name: assigndevice assignid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.assigndevice ALTER COLUMN assignid SET DEFAULT nextval('public.assigndevice_assignid_seq'::regclass);


--
-- Name: creditinstallment installmentid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.creditinstallment ALTER COLUMN installmentid SET DEFAULT nextval('public.creditinstallment_installmentid_seq'::regclass);


--
-- Name: devicesale saleid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.devicesale ALTER COLUMN saleid SET DEFAULT nextval('public.devicesale_saleid_seq'::regclass);


--
-- Name: employee employeeid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.employee ALTER COLUMN employeeid SET DEFAULT nextval('public."Employee_EmployeeID_seq"'::regclass);


--
-- Name: farm farmid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.farm ALTER COLUMN farmid SET DEFAULT nextval('public.farm_farmid_seq'::regclass);


--
-- Name: inventory deviceid; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory ALTER COLUMN deviceid SET DEFAULT nextval('public.inventory_deviceid_seq'::regclass);


--
-- Name: itemtable serialno; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.itemtable ALTER COLUMN serialno SET DEFAULT nextval('public.itemtable_serialno_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.admin (serial, email, password) FROM stdin;
\.
COPY public.admin (serial, email, password) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: assigndevice; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.assigndevice (assignid, employeeid, deviceid, quantity, "timestamp") FROM stdin;
\.
COPY public.assigndevice (assignid, employeeid, deviceid, quantity, "timestamp") FROM '$$PATH$$/3417.dat';

--
-- Data for Name: creditinstallment; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.creditinstallment (installmentid, saleid, deadline, paymentdate, status, promisedamount, amountpaid) FROM stdin;
\.
COPY public.creditinstallment (installmentid, saleid, deadline, paymentdate, status, promisedamount, amountpaid) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: devicesale; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.devicesale (saleid, saletype, employeeid, customername, customeridimage, phoneno, language, unit, farm, itemarray, totalcost, totalsale, remark, "timestamp", status, amountleft, paymentalert) FROM stdin;
\.
COPY public.devicesale (saleid, saletype, employeeid, customername, customeridimage, phoneno, language, unit, farm, itemarray, totalcost, totalsale, remark, "timestamp", status, amountleft, paymentalert) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.employee (employeeid, employeephoto, firstname, lastname, phoneno, password, email) FROM stdin;
\.
COPY public.employee (employeeid, employeephoto, firstname, lastname, phoneno, password, email) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: farm; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.farm (farmid, farmname) FROM stdin;
\.
COPY public.farm (farmid, farmname) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: farmunit; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.farmunit (unitname, farmname) FROM stdin;
\.
COPY public.farmunit (unitname, farmname) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.inventory (deviceid, company, devicedetail, cost, storage, itemtype, remark, inuse) FROM stdin;
\.
COPY public.inventory (deviceid, company, devicedetail, cost, storage, itemtype, remark, inuse) FROM '$$PATH$$/3413.dat';

--
-- Data for Name: itemtable; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.itemtable (serialno, itemtype) FROM stdin;
\.
COPY public.itemtable (serialno, itemtype) FROM '$$PATH$$/3415.dat';

--
-- Name: Employee_EmployeeID_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Employee_EmployeeID_seq"', 2, true);


--
-- Name: admin_Serial_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."admin_Serial_seq"', 1, true);


--
-- Name: assigndevice_assignid_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.assigndevice_assignid_seq', 15, true);


--
-- Name: creditinstallment_installmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.creditinstallment_installmentid_seq', 4, true);


--
-- Name: devicesale_saleid_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.devicesale_saleid_seq', 3, true);


--
-- Name: farm_farmid_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.farm_farmid_seq', 2, true);


--
-- Name: inventory_deviceid_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.inventory_deviceid_seq', 3, true);


--
-- Name: itemtable_serialno_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.itemtable_serialno_seq', 9, true);


--
-- Name: employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (employeeid);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (serial);


--
-- Name: assigndevice assigndevice_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.assigndevice
    ADD CONSTRAINT assigndevice_pkey PRIMARY KEY (assignid);


--
-- Name: creditinstallment creditinstallment_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.creditinstallment
    ADD CONSTRAINT creditinstallment_pkey PRIMARY KEY (installmentid);


--
-- Name: devicesale devicesale_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.devicesale
    ADD CONSTRAINT devicesale_pkey PRIMARY KEY (saleid);


--
-- Name: farm farm_farmname_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.farm
    ADD CONSTRAINT farm_farmname_key UNIQUE (farmname);


--
-- Name: farm farm_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.farm
    ADD CONSTRAINT farm_pkey PRIMARY KEY (farmid);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (deviceid);


--
-- Name: itemtable itemtable_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.itemtable
    ADD CONSTRAINT itemtable_pkey PRIMARY KEY (serialno);


--
-- PostgreSQL database dump complete
--

